#include "Laptop.h"
#include "Cellphone.h"
#include "Smartwatch.h"
#include <iostream>
using namespace std;

int main() {
  return 0;
}
