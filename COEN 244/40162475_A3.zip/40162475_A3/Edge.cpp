#include "Edge.h"

//Accessing functions
Edge::getWeight() const {return weight;}
Edge::getStart() const {return startV;}
Edge::getEnd() const {return endV;}
