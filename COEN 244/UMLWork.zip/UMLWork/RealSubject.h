#include "Subject.h"

class RealSubject : public Subject {
public:
  void dolt();
};
