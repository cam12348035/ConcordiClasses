#include "Subject.h"

class Proxy : public Subject {
private:
  int wrapee;
    RealSubject subjectlist[10];
public:
  void dolt();

};
